<?php
    $idVehiculo=$_GET['idVehiculo'];
    $placa=$_GET['placa'];
    $numeroSerie=$_GET['numeroSerie'];
    $fecha=$_GET['fecha'];
    $municipio=$_GET['municipio'];
    $origen=$_GET['origen'];
    $modelo=$_GET['modelo'];
    $marca=$_GET['marca'];
    $folio=$_GET['folio'];
    $transmision=$_GET['transmision'];
    $cilindraje=$_GET['cilindraje'];
    $capacidad=$_GET['capacidad'];
    $noPuerta=$_GET['noPuerta'];
    $noAsientos=$_GET['noAsientos'];
    $noMotor=$_GET['noMotor'];
    $clase=$_GET['clase'];
    $tipo=$_GET['tipo'];
    $uso=$_GET['uso'];
    $rfa=$_GET['rfa'];
    $color=$_GET['color'];
    $localidad=$_GET['localidad'];
    $cveVehicular=$_GET['cveVehicular'];
    $placaAnterior=$_GET['placaAnterior'];
    $tipoCombustible=$_GET['tipoCombustible'];
    

    
    
    print("Id de Vehiculo ".$idVehiculo."<br>");
    print("Placa ".$placa."<br>");
    print("Numero de Serie ".$numeroSerie."<br>");
    print("Fecha ".$fecha."<br>");
    print("Municipio ".$municipio."<br>");
    print("Origen ".$origen."<br>");
    print("Modelo ".$modelo."<br>");
    print("Marca ".$marca."<br>");
    print("Folio ".$folio."<br>");
    print("Transmision ".$transmision."<br>");
    print("Cilindraje ".$cilindraje."<br>");
    print("Capacidad ".$capacidad."<br>");
    print("Numero de Puertas ".$noPuerta."<br>");
    print("Numero de Asientos ".$noAsientos."<br>");
    print("Numero de Motor ".$noMotor."<br>");
    print("Clase ".$clase."<br>");
    print("Tipo ".$tipo."<br>");
    print("Uso ".$uso."<br>");
    print("Rfa ".$rfa."<br>");
    print("Color ".$color."<br>");
    print("Localidad ".$localidad."<br>");
    print("Clave Vehicular ".$cveVehicular."<br>");
    print("Placa Anterior ".$placaAnterior."<br>");
    print("Tipo de Combustible ".$tipoCombustible."<br>");

    $SQL = "INSERT INTO Vehiculos VALUES ('$idVehiculo','$placa','$numeroSerie','$fecha','$municipio','$origen','$modelo','$marca','$folio','$transmision','$cilindraje','$capacidad','$noPuerta','$noAsientos','$noMotor','$clase','$tipo','$uso','$rfa','$color','$localidad','$cveVehicular','$placaAnterior','$tipoCombustible')";
    print($SQL);
    include("Controlador.php");
    $Con = Conectar();
    $Resul=Ejecutar($Con,$SQL);
    $FilasAfectadas = mysqli_affected_rows($Con);
    if ($FilasAfectadas == 1) {
        print("1 Registro Insertado")
    }else{
        print("Registro no insertado")
    }
    Desconectar($Con);
?>